
(function() {
  'use strict';
  
  
  angular.module('rapp')
    .controller('CourseCtrl', ['DataCtx','$rootScope',Course]);
   
  function Course(DataCtx, $rootScope) {
    var vm = this;
    vm.Modules = [];
    
    $rootScope.$broadcast('http-loading', 
      {
        loading:DataCtx.modules.query().$promise.then(loadModules, errLoading)
      }
    );
    
    function loadModules(data){
      vm.Modules = data;
    }
    
    function errLoading(err){
      console.log('Error...');
    }
  }
  
})();
