(function () {
  'use strict';

  angular.module('rapp')
    .controller('ScheduleCtrl',
    ['DataCtx',
      'localStorageService',
      'ngDialog',
      '$rootScope','_m',
      ScheduleCtrl])
    .controller('ScheduleManageCtrl',
    ['DataCtx',
      'localStorageService',
      'ngDialog',
      '$rootScope','$state',
      ScheduleManageCtrl])
    .controller('ScheduleCreateCtrl',
    ['DataCtx',
      'localStorageService',
      'ngDialog',
      '$rootScope',
      '_m','$state',
      ScheduleCreateCtrl]);

  function ScheduleCtrl(DataCtx, localStorageService, ngDialog, $rootScope, _m) {
    var vm = this;
    vm.page = {
      title: "Sessions",
      subTitle: "Upcoming Classes"
    };

    vm.sessions = [];
    vm.bookSession = bookSession;

    function bookSession(session){
      console.log(session);
    }

    DataCtx.session.get().$promise.then(loadSessions, errLoading);

    function loadSessions(res) {
      if(angular.isArray(res.data)){
        vm.sessions = res.data;
      }else{
        Materialize.toast("Error loading Sessions", 2000);
      }
    }

    function errLoading() {
      Materialize.toast("Session Expired, log In", 2000);
    }
  }

  function ScheduleManageCtrl(DataCtx, localStorageService, ngDialog, $rootScope, $state) {
    var vm = this;
    vm.page = {
      title: "Manage Sessions",
    };
    vm.schedules = [
      {
        "session_datetime": "2016/7/21",
        "level": "BEGINNER",
        "slots": "10",
        "location": "Sandton",
        "duration": "2"
      }, {
        "session_datetime": "2016/7/21",
        "level": "BEGINNER",
        "slots": "10",
        "location": "Sandton",
        "duration": "2"
      }, {
        "session_datetime": "2016/7/21",
        "level": "ADVANCED",
        "slots": "9",
        "location": "Sandton",
        "duration": "2"
      }
    ];
    vm.edit = edit;
    vm.add = add;

    function edit(session) {

    }

    function add() {
      $state.go('schedule-create');
    }


  }

  function ScheduleCreateCtrl(DataCtx, localStorageService, ngDialog, $rootScope, _m, $state) {
    var vm = this;
    vm.page = {
      title: "Create Session"
    };
    var currentTime = new Date();
    vm.currentTime = currentTime;
    vm.minDate  = (new Date(vm.currentTime.getTime())).toISOString();;
    console.log(vm.minDate);
    vm.schedule = {
      recuring: false
    };


    vm.createSchedule = createSchedule;

    function createSchedule() {

      if(angular.isDefined(vm.time) && angular.isDefined(vm.schedule.session_date))
      {
        vm.schedule.day = _m(vm.schedule.session_date + " " + vm.time, "DD-MM-YYYY HH:mm");
        var Session = new DataCtx.session();
        Session.day      = vm.schedule.day.format("YYYY-MM-DD HH:mm:ss");
        Session.slots    = vm.schedule.slots
        Session.duration = vm.schedule.duration;
        Session.location = vm.schedule.location;
        Session.level    = vm.schedule.level;
        Session.note     = vm.schedule.notes;
        Session.recuring    = vm.schedule.recuring;
        Session.day_week    = vm.schedule.day.day();
         Session.$save().then(function (res) {
           if (res.code=="00") {
             Materialize.toast("Session saved Successful", 2000);
             $state.go('schedule-manage');
           } else {
             Materialize.toast("Failed to save Session", 2000);
           }
       }, function(){
          Materialize.toast("Something Went Wrong", 2000);
       });
      }
    }
  }

})();
