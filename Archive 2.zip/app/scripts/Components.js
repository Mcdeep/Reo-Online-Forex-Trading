
(function(){
  angular.module('rapp')
    .factory('_m', function(){
        return window.moment;
    })
    .component('pageHeader', {
      template: `
      <div id="hero-2" class="mdl-layout_content">
          <div class="container">
              <div class="row">
                  <div class="col s12">
                      <h2 style="text-align:center">{{ $ctrl.page.title }}</h2>
                      <p style="text-align:center">{{ $ctrl.page.subTitle }}</p>
                  </div>
              </div>
          </div>
      </div>
      `,
      bindings: {
        page: '=',
      }
    }).component('sessionItem', {
      template: `
      <div class="col s12 item">
          <div class="col s7">
              <div class="col s12">
                <div class="col s3 day">
                  <h3>12</h3>
                  <span>Wed</span>
                </div>
                <div class="col s8">
                  <p class="time">
                    <i class="fa fa-clock-o" style="font-size:18px; margin-right:5px" ></i>time
                  </p>
                  <p class="level">
                    BEGINNER
                  </p>
                </div>
              </div>
          </div>
          <div class="col s5" style="text-align:center">
              <p class="slots">
                16 Available Slots
              </p>

              <button ng-click="$ctrl.book()" class="waves-effect btn-radius blue-grey btn-small waves-light btn">
                     Book
              </button>
          </div>
      </div>
      `,
      bindings: {
        session: '=',
        onBook : '&'
      },
      controller: SessionController
    });

    function SessionController(){
      var vm = this;

      vm.book = book;

      function book(){
        vm.onBook({ session:vm.session });
      }
    }

})();
