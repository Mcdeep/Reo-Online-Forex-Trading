(function () {
  'use strict';


  angular.module('rapp')
    .controller('LoginCtrl', ['DataCtx', 'localStorageService', 'ngDialog','$rootScope', LoginCtrl]);


  function LoginCtrl(DataCtx, localStorageService, ngDialog, $rootScope) {
    var vm = this;
    Materialize.toast("Login In...", 1000);
    vm.login = login;

    function login() {
      if (vm.log.email !== "" && vm.log.password !== "") {
        var Login = new DataCtx.auth();
        Login.email = vm.log.email;
        Login.password = vm.log.password;

        Login.$save().then(function (res) {
          if (angular.isDefined(res.token)) {
            Materialize.toast("Login Successful", 2000);
            localStorageService.set('token', res.token);
            localStorageService.set('userInfo', res.userinfo);
            vm.log.email    = "";
            vm.log.password = "";
            $rootScope.$broadcast('quiz-login',{loginUser: res.userinfo});
            ngDialog.close();
          } else {
            Materialize.toast("Failed to Login", 2000);
          }
        }, function () {
          Materialize.toast("Unable to Reach the Server", 2000);
        });
      }

    }
  }

})();
