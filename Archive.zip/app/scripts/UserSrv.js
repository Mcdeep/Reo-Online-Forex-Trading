(function () {
  'use strict';

  angular.module('rapp')
    .factory('User', ['DataCtx',UserSrv]);


  function UserSrv(DataCtx) {
    return {
      checkUserAuth: checkUserAuth
    };
    
    function checkUserAuth(){
     
    }
  }
})();