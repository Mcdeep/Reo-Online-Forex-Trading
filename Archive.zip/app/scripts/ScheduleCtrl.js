(function () {
  'use strict';

  angular.module('rapp')
    .controller('ScheduleCtrl',
      ['DataCtx',
        'localStorageService',
        'ngDialog',
        '$rootScope',
        ScheduleCtrl]);

  angular.module('rapp')
    .controller('ScheduleManageCtrl',
      ['DataCtx',
        'localStorageService',
        'ngDialog',
        '$rootScope',
        ScheduleManageCtrl]);

  angular.module('rapp')
    .controller('ScheduleCreateCtrl',
      ['DataCtx',
        'localStorageService',
        'ngDialog',
        '$rootScope',
        ScheduleCreateCtrl]);

  function ScheduleCtrl(DataCtx, localStorageService, ngDialog, $rootScope) {
    var vm = this;

  }

  function ScheduleManageCtrl(DataCtx, localStorageService, ngDialog, $rootScope) {
    var vm = this;
    vm.schedules = [];



    vm.edit = edit;
    vm.add  = add;

    function edit(session){

    }

    function add(){

    }


  }

  function ScheduleCreateCtrl(DataCtx, localStorageService, ngDialog, $rootScope) {
    var vm = this;

  }

})();
