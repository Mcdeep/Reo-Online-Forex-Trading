(function () {
  'use strict';

  angular.module('rapp')
    .factory('DataCtx', ['$resource',DataCtx]);


  function DataCtx($resource) {
    var endpoint = 'http://127.0.0.1:9003/api/';
    return {
      modules: $resource(endpoint + 'module/:id', {id: '@id'}),
      lesson: $resource(endpoint + 'lesson/:id', {id: '@id'}),
      quiz: $resource(endpoint + 'quiz/:id', {id: '@id'}),
      auth: $resource(endpoint + 'authenticate/:id', {id: '@id'}),
      user:$resource(endpoint + 'registration') 
    };

  }
})();