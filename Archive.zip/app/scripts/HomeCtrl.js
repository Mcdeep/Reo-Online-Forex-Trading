(function () {
  'use strict';


  angular.module('rapp')
    .controller('HomeCtrl', ['DataCtx', 'ngDialog', HomeCtrl])
    .controller('LayoutCtrl', ['$scope', 'ngDialog', 'DataCtx', LayoutCtrl]);

  //Home Controller 
  function HomeCtrl(DataCtx, ngDialog) {
    var vm = this;

    vm.registerUser = registerUser;

    function registerUser() {
      var UserResource = new DataCtx.user();

      UserResource.firstname = vm.user.firstname;
      UserResource.lastname = vm.user.lastname;
      UserResource.country = vm.user.country;
      UserResource.cellphone = vm.user.cellphone;
      UserResource.city = vm.user.city;
      UserResource.email = vm.user.email;
      UserResource.password = vm.user.password;

      UserResource.$save().then(function (res) {
        if (res.code === "00") {

          vm.user.firstname ="";
          vm.user.lastname  ="";
          vm.user.country   ="";
          vm.user.cellphone ="";
          vm.user.city      ="";
          vm.user.email     ="";
          vm.user.password  ="";
          ngDialog.open({
            template: 'templates/registration_dialog.tmpl.html',
            className: 'ngdialog-theme-default registration',
            controller: function () {

            },
            controllerAs: 'vm'
          });

        } else {
          console.log(res);
        }
      });
    }
  }

  //Layout Controller 
  function LayoutCtrl($scope, ngDialog) {
    var lt = this;
    lt.quiz = false;
    lt.loggedIn = false;
    
    $scope.$on('quiz-login', function(event, data){
      lt.loggedIn = true;
      lt.loginUser = data.loginUser.fname;
    });

    $scope.$on('quiz-view', function (event, data) {
      lt.quiz = data.menu;
    });
    
    $scope.$on('http-loading', function(event, data){
      console.log('Setting loading', data.loading);
      lt.loading = data.loading;
    });

    lt.openLogin = function () {
      ngDialog.open({
        template: 'login.form.html',
        className: 'ngdialog-theme-default',
        controller: 'LoginCtrl',
        controllerAs: 'vm'
      });
    };

    lt.closeLogin = function () {
    };

  }
})();